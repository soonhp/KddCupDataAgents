"""Entry point for the KDD Cup 2026 Data Agents submission.

This script serves as a thin wrapper around your agent’s evaluation
runner.  It discovers and executes your solution’s entry point,
iterating over all tasks located under `/input/task_<id>/` and
writing prediction results to `/output/task_<id>/prediction.csv`.  At
runtime the evaluation system injects environment variables for the
model service (MODEL_API_URL, MODEL_API_KEY, MODEL_NAME) and mounts
`/input`, `/output`, and `/logs` as described in the official
specifications【497822211969844†L159-L167】.  Do not hardcode any
sensitive information; always read configuration from the environment.
"""

from __future__ import annotations

import sys
from importlib import import_module


def main() -> None:
    """Invoke your evaluation runner.

    This function attempts to import the module
    `runner.evaluation_runner` and call its `main()` function.  If
    your evaluation runner exposes a different entry point (e.g., a
    function named `run()`), adjust the logic accordingly.  If the
    import fails, a user‑friendly error message is emitted.
    """
    try:
        evaluation_runner = import_module("runner.evaluation_runner")
    except ImportError as exc:  # pragma: no cover - startup import error
        raise SystemExit(
            f"Unable to import runner.evaluation_runner: {exc}" 
        ) from exc

    # Delegate to the appropriate function
    if hasattr(evaluation_runner, "main"):
        evaluation_runner.main()
    elif hasattr(evaluation_runner, "run"):
        evaluation_runner.run()
    else:
        raise SystemExit(
            "Your evaluation runner must define a 'main' or 'run' function."
        )


if __name__ == "__main__":  # pragma: no cover
    main()