# KDD Cup 2026 Data Agents Docker Packaging

This directory contains a minimal **Docker packaging template** that complies with
the KDD Cup 2026 Data Agents competition submission rules.  You can use it as a
starting point to package your agent for submission.

## Directory contents

```
kdd_submission_final/
├── Dockerfile       # Defines the container environment and start‑up command
├── requirements.txt # List of Python dependencies for your agent
└── main.py          # Entry point that invokes your agent’s evaluation runner
```

### Dockerfile

The provided `Dockerfile` uses a slim Python base image, copies your source code
into the container, installs dependencies via `pip`, and sets up the entry point
to run the evaluation runner.  It also redirects stdout/stderr into
`/logs/runtime.log` as recommended in the official rules【497822211969844†L320-L336】.

### requirements.txt

Add all the Python packages your agent depends on to this file.  In the sample
we include `pandas` and `numpy`, but you should extend it with any other
libraries required by your solution.  The evaluation environment has no
pre‑installed packages beyond the Python standard library, so list everything
explicitly.

### main.py

This script imports your evaluation runner (from `runner.evaluation_runner`) and
invokes its `main()` function.  If your agent exposes a different entry
function, adjust the import and invocation accordingly.  The evaluation system
mounts the dataset at `/input` and the output directory at `/output`, so your
evaluation runner should read tasks from `/input/task_<id>/` and write
`prediction.csv` files to `/output/task_<id>/`【497822211969844†L159-L167】.

## Building and exporting your submission

1. Place this directory in the root of your agent repository so that
   `runner/evaluation_runner.py` and all other source files are available when
   `COPY . /app` runs in the Dockerfile.

2. Replace `<team_id>` with the unique team identifier assigned by the
   organizers and `<version>` with your submission version number (starting
   from 1).  Build the Docker image using:

   ```bash
   docker build -t <team_id>:v<version> .
   ```

3. Export the image into a gzipped tar archive using the required naming
   convention (`<team_id>_v<version>.tar.gz`)【497822211969844†L169-L187】:

   ```bash
   docker save <team_id>:v<version> | gzip > <team_id>_v<version>.tar.gz
   ```

4. Upload the archive to your own Google Drive and set sharing permissions to
   “Anyone with the link”.  Email the link to the organizers following the
   instructions in Section 3.3 of the rules【497822211969844†L213-L235】.

For more details about the submission process, naming conventions, and runtime
environment constraints, refer to Section 3 of the official technical
specifications【497822211969844†L159-L167】.